document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("qrBuilder");
  const textInput = document.getElementById("qrText");
  const sizeInput = document.getElementById("qrSize");
  const sizeValue = document.getElementById("sizeValue");
  const previewSize = document.getElementById("previewSize");
  const foregroundInput = document.getElementById("qrForeground");
  const backgroundInput = document.getElementById("qrBackground");
  const errorInput = document.getElementById("qrError");
  const preview = document.getElementById("qrPreview");
  const statusPill = document.getElementById("qrStatus");
  const statusMessage = document.getElementById("statusMessage");
  const charCount = document.getElementById("charCount");
  const formatLabel = document.getElementById("formatLabel");
  const downloadButton = document.getElementById("downloadQr");
  const copyButton = document.getElementById("copyText");
  const resetButton = document.getElementById("resetForm");
  const presetButtons = document.querySelectorAll("[data-fill]");

  const defaultState = {
    text: textInput.value,
    size: sizeInput.value,
    foreground: foregroundInput.value,
    background: backgroundInput.value,
    error: errorInput.value,
  };

  let debounceId = null;

  function getCurrentText() {
    return textInput.value.trim();
  }

  function detectFormat(value) {
    if (!value) {
      return "Waiting for input";
    }

    try {
      const parsed = new URL(value);
      return parsed.protocol.startsWith("http") ? "Website" : "Link";
    } catch (error) {
      return value.includes("@") && value.includes(".") ? "Contact" : "Text";
    }
  }

  function updateReadouts() {
    const text = getCurrentText();
    const size = Number(sizeInput.value);

    sizeValue.textContent = `${size} px`;
    previewSize.textContent = `${size} x ${size}`;
    charCount.textContent = String(text.length);
    formatLabel.textContent = detectFormat(text);
  }

  function setStatus(message, tone = "neutral") {
    statusMessage.textContent = message;
    statusPill.textContent = tone === "success" ? "Ready" : tone === "warning" ? "Needs input" : "Live";
    statusPill.className = `status-pill status-${tone}`;
  }

  function renderPlaceholder(message) {
    preview.innerHTML = `
      <div class="qr-empty text-center">
        <div class="qr-empty-icon">
          <i class="bi bi-qr-code-scan"></i>
        </div>
        <h3 class="h5 mt-3 mb-2">${message}</h3>
        <p class="text-muted mb-0">Enter content, adjust the style, and generate a QR code that is ready to scan.</p>
      </div>
    `;
  }

  function clearPreview() {
    preview.innerHTML = "";
  }

  function generateQrCode() {
    if (!window.QRCode) {
      renderPlaceholder("QR library failed to load");
      setStatus("The QR code library is unavailable right now.", "warning");
      return;
    }

    const value = getCurrentText();
    updateReadouts();

    if (!value) {
      renderPlaceholder("Your QR code will appear here");
      setStatus("Add text or a URL before generating the QR code.", "warning");
      return;
    }

    clearPreview();

    try {
      new QRCode(preview, {
        text: value,
        width: Number(sizeInput.value),
        height: Number(sizeInput.value),
        colorDark: foregroundInput.value,
        colorLight: backgroundInput.value,
        correctLevel: QRCode.CorrectLevel[errorInput.value],
      });

      setStatus("QR code generated and ready to scan.", "success");
    } catch (error) {
      renderPlaceholder("Unable to build the QR code");
      setStatus("Something prevented the QR code from being created.", "warning");
    }
  }

  function scheduleGenerate() {
    window.clearTimeout(debounceId);
    debounceId = window.setTimeout(generateQrCode, 180);
  }

  async function copyCurrentText() {
    const value = getCurrentText();

    if (!value) {
      setStatus("There is no text to copy yet.", "warning");
      return;
    }

    try {
      await navigator.clipboard.writeText(value);
      setStatus("Content copied to the clipboard.", "success");
    } catch (error) {
      setStatus("Clipboard access is not available in this browser.", "warning");
    }
  }

  function downloadCurrentQr() {
    const canvas = preview.querySelector("canvas");
    const image = preview.querySelector("img");

    if (canvas) {
      const link = document.createElement("a");
      link.href = canvas.toDataURL("image/png");
      link.download = "creative-vsion-qr-code.png";
      link.click();
      setStatus("QR code downloaded as PNG.", "success");
      return;
    }

    if (image) {
      const link = document.createElement("a");
      link.href = image.src;
      link.download = "creative-vsion-qr-code.png";
      link.click();
      setStatus("QR code downloaded as PNG.", "success");
      return;
    }

    setStatus("Generate a QR code before downloading it.", "warning");
  }

  function resetForm() {
    textInput.value = defaultState.text;
    sizeInput.value = defaultState.size;
    foregroundInput.value = defaultState.foreground;
    backgroundInput.value = defaultState.background;
    errorInput.value = defaultState.error;
    updateReadouts();
    generateQrCode();
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    generateQrCode();
  });

  textInput.addEventListener("input", scheduleGenerate);
  sizeInput.addEventListener("input", scheduleGenerate);
  foregroundInput.addEventListener("input", scheduleGenerate);
  backgroundInput.addEventListener("input", scheduleGenerate);
  errorInput.addEventListener("change", scheduleGenerate);

  presetButtons.forEach((button) => {
    button.addEventListener("click", () => {
      textInput.value = button.dataset.fill || "";
      updateReadouts();
      generateQrCode();
    });
  });

  downloadButton.addEventListener("click", downloadCurrentQr);
  copyButton.addEventListener("click", copyCurrentText);
  resetButton.addEventListener("click", resetForm);

  updateReadouts();
  renderPlaceholder("Your QR code will appear here");
  generateQrCode();
});